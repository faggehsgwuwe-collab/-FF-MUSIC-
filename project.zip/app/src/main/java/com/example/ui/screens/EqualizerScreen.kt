package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EqualizerState
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun EqualizerScreen(
    equalizerState: EqualizerState,
    onToggleEnabled: (Boolean) -> Unit,
    onBandChange: (bandIndex: Int, levelMilliBels: Int) -> Unit,
    onBassBoostChange: (Int) -> Unit,
    onVirtualizerChange: (Int) -> Unit,
    onPresetSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val presets = listOf(
        "Normal", "Bass Boost", "Rock", "Pop", "Jazz",
        "Metal", "Classical", "Dance", "Hip Hop"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Master switch header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Audio Equalizer & FX",
                        color = TextWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (equalizerState.isEnabled) "Effects Active (Hardware Studio Level)" else "Bypassed",
                        color = if (equalizerState.isEnabled) GoldSecondary else TextMuted,
                        fontSize = 12.sp
                    )
                }

                Switch(
                    checked = equalizerState.isEnabled,
                    onCheckedChange = onToggleEnabled,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = GoldSecondary,
                        checkedTrackColor = GoldDark,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = ObsidianBorder
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Presets Chips Carousel
        Text(
            text = "PRESETS",
            color = GoldDark,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            presets.forEach { preset ->
                val isSelected = equalizerState.currentPreset == preset
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) GoldPrimary else ObsidianCard)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) GoldSecondary else ObsidianBorder,
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable(enabled = equalizerState.isEnabled) {
                            onPresetSelected(preset)
                        }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = preset,
                        color = if (isSelected) ObsidianBlack else TextWhite,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Frequency Bands
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "FREQUENCY BANDS",
                    color = GoldDark,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                val bands = if (equalizerState.bands.isNotEmpty()) {
                    equalizerState.bands
                } else {
                    // Fallback visual bands if hardware bands loading
                    listOf(
                        com.example.model.EqualizerBand(0, 60, -1500, 1500, 0),
                        com.example.model.EqualizerBand(1, 230, -1500, 1500, 0),
                        com.example.model.EqualizerBand(2, 910, -1500, 1500, 0),
                        com.example.model.EqualizerBand(3, 3600, -1500, 1500, 0),
                        com.example.model.EqualizerBand(4, 14000, -1500, 1500, 0)
                    )
                }

                bands.forEach { band ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = band.centerFreqFormatted,
                            color = GoldPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.width(72.dp)
                        )

                        val minL = band.minLevelMilliBels.toFloat()
                        val maxL = band.maxLevelMilliBels.toFloat()

                        Slider(
                            value = band.currentLevelMilliBels.toFloat(),
                            onValueChange = { newLevel ->
                                onBandChange(band.index, newLevel.toInt())
                            },
                            valueRange = minL..maxL,
                            enabled = equalizerState.isEnabled,
                            colors = SliderDefaults.colors(
                                thumbColor = GoldSecondary,
                                activeTrackColor = GoldPrimary,
                                inactiveTrackColor = ObsidianBorder
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        val db = band.currentLevelMilliBels / 100
                        Text(
                            text = "${if (db > 0) "+" else ""}$db dB",
                            color = TextMuted,
                            fontSize = 12.sp,
                            modifier = Modifier.width(52.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.End
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Bass Boost & 3D Virtualizer Cards
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Bass Boost
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Bass Booster", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "${equalizerState.bassBoost / 10}%", color = GoldSecondary, fontSize = 13.sp)
                }
                Slider(
                    value = equalizerState.bassBoost.toFloat(),
                    onValueChange = { onBassBoostChange(it.toInt()) },
                    valueRange = 0f..1000f,
                    enabled = equalizerState.isEnabled,
                    colors = SliderDefaults.colors(
                        thumbColor = GoldSecondary,
                        activeTrackColor = GoldPrimary,
                        inactiveTrackColor = ObsidianBorder
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Virtualizer (3D Surround)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "3D Virtualizer (Surround Sound)", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "${equalizerState.virtualizer / 10}%", color = GoldSecondary, fontSize = 13.sp)
                }
                Slider(
                    value = equalizerState.virtualizer.toFloat(),
                    onValueChange = { onVirtualizerChange(it.toInt()) },
                    valueRange = 0f..1000f,
                    enabled = equalizerState.isEnabled,
                    colors = SliderDefaults.colors(
                        thumbColor = GoldSecondary,
                        activeTrackColor = GoldPrimary,
                        inactiveTrackColor = ObsidianBorder
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(64.dp))
    }
}
