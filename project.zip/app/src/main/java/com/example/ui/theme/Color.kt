package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Black & Gold Palette
val GoldPrimary = Color(0xFFD4AF37)
val GoldSecondary = Color(0xFFFFD700)
val GoldTertiary = Color(0xFFE5C158)
val GoldLight = Color(0xFFFFF0B8)
val GoldDark = Color(0xFFA68010)

val ObsidianBlack = Color(0xFF0A0A0C)
val ObsidianSurface = Color(0xFF141416)
val ObsidianCard = Color(0xFF1E1E22)
val ObsidianCardElevated = Color(0xFF28282E)
val ObsidianBorder = Color(0xFF332D1C)

val TextWhite = Color(0xFFFBFBFB)
val TextMuted = Color(0xFFA0A0A5)
val TextGold = Color(0xFFFFDF7D)

val SuccessGreen = Color(0xFF4CAF50)
val ErrorRed = Color(0xFFE53935)
val WarningOrange = Color(0xFFFFA000)
