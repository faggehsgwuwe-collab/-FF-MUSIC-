package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.model.VisualizerMode
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.GoldTertiary
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BeatVisualizerCanvas(
    waveformData: ByteArray,
    fftData: ByteArray,
    isPlaying: Boolean,
    mode: VisualizerMode,
    modifier: Modifier = Modifier,
    primaryColor: Color = GoldPrimary,
    accentColor: Color = GoldSecondary
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        if (width <= 0f || height <= 0f) return@Canvas

        when (mode) {
            VisualizerMode.SPECTRUM -> {
                val numBars = 36
                val barSpacing = 4f
                val barWidth = (width - (numBars - 1) * barSpacing) / numBars
                val gradient = Brush.verticalGradient(
                    colors = listOf(accentColor, primaryColor, GoldTertiary.copy(alpha = 0.3f)),
                    startY = 0f,
                    endY = height
                )

                for (i in 0 until numBars) {
                    val fftIndex = (i * fftData.size / numBars).coerceIn(0, fftData.size - 1)
                    val rawEnergy = abs(fftData[fftIndex].toInt()).toFloat()
                    val normalized = if (isPlaying) (rawEnergy / 128f).coerceIn(0.08f, 1f) else 0.05f
                    val barHeight = height * normalized * 0.9f

                    val left = i * (barWidth + barSpacing)
                    val top = height - barHeight

                    drawRect(
                        brush = gradient,
                        topLeft = Offset(left, top),
                        size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
                    )

                    // Falling peak cap
                    val capHeight = 4f
                    val capTop = (top - 8f).coerceAtLeast(0f)
                    drawRect(
                        color = Color.White.copy(alpha = 0.9f),
                        topLeft = Offset(left, capTop),
                        size = androidx.compose.ui.geometry.Size(barWidth, capHeight)
                    )
                }
            }

            VisualizerMode.WAVEFORM -> {
                val path = Path()
                val midY = height / 2f
                val points = waveformData.size.coerceAtLeast(2)
                val stepX = width / (points - 1)

                for (i in 0 until points) {
                    val sample = if (isPlaying) (waveformData[i].toInt() - 128) / 128f else 0f
                    val y = midY + sample * (height * 0.4f)
                    val x = i * stepX
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }

                // Glowing outer stroke
                drawPath(
                    path = path,
                    color = primaryColor.copy(alpha = 0.4f),
                    style = Stroke(width = 8f)
                )
                // Core bright wave
                drawPath(
                    path = path,
                    color = accentColor,
                    style = Stroke(width = 3.5f)
                )
            }

            VisualizerMode.BASS_PULSE -> {
                val centerX = width / 2f
                val centerY = height / 2f
                val maxRadius = minOf(width, height) * 0.45f

                // Estimate bass energy from lower FFT frequencies
                val bassEnergy = if (isPlaying && fftData.isNotEmpty()) {
                    var sum = 0
                    val sampleCount = minOf(8, fftData.size)
                    for (i in 0 until sampleCount) {
                        sum += abs(fftData[i].toInt())
                    }
                    (sum / (sampleCount * 128f)).coerceIn(0.1f, 1f)
                } else 0.15f

                val pulseRadius = maxRadius * (0.6f + bassEnergy * 0.4f)

                // Outer pulsing aura rings
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(primaryColor.copy(alpha = 0.35f * bassEnergy), Color.Transparent),
                        center = Offset(centerX, centerY),
                        radius = pulseRadius * 1.3f
                    ),
                    center = Offset(centerX, centerY),
                    radius = pulseRadius * 1.3f
                )

                // Middle glowing gold ring
                drawCircle(
                    color = primaryColor,
                    center = Offset(centerX, centerY),
                    radius = pulseRadius,
                    style = Stroke(width = 5f + bassEnergy * 6f)
                )

                // Inner core gold disc
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(accentColor, primaryColor, Color(0xFF141416)),
                        center = Offset(centerX, centerY),
                        radius = pulseRadius * 0.7f
                    ),
                    center = Offset(centerX, centerY),
                    radius = pulseRadius * 0.7f
                )
            }

            VisualizerMode.CIRCULAR -> {
                val centerX = width / 2f
                val centerY = height / 2f
                val baseRadius = minOf(width, height) * 0.28f
                val numSpikes = 48
                val angleStep = (2 * PI) / numSpikes

                for (i in 0 until numSpikes) {
                    val angle = i * angleStep
                    val fftIdx = (i * fftData.size / numSpikes).coerceIn(0, fftData.size - 1)
                    val energy = if (isPlaying) (abs(fftData[fftIdx].toInt()) / 128f).coerceIn(0.05f, 1f) else 0.05f
                    val spikeLength = 60f * energy

                    val startX = centerX + cos(angle).toFloat() * baseRadius
                    val startY = centerY + sin(angle).toFloat() * baseRadius
                    val endX = centerX + cos(angle).toFloat() * (baseRadius + spikeLength)
                    val endY = centerY + sin(angle).toFloat() * (baseRadius + spikeLength)

                    drawLine(
                        color = if (i % 2 == 0) accentColor else primaryColor,
                        start = Offset(startX, startY),
                        end = Offset(endX, endY),
                        strokeWidth = 3.5f
                    )
                }

                // Inner ring
                drawCircle(
                    color = primaryColor.copy(alpha = 0.5f),
                    center = Offset(centerX, centerY),
                    radius = baseRadius,
                    style = Stroke(width = 2.5f)
                )
            }
        }
    }
}
