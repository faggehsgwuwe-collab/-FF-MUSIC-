package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BlackGoldColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = ObsidianBlack,
    primaryContainer = GoldDark,
    onPrimaryContainer = GoldLight,
    secondary = GoldSecondary,
    onSecondary = ObsidianBlack,
    secondaryContainer = ObsidianCardElevated,
    onSecondaryContainer = GoldLight,
    tertiary = GoldTertiary,
    onTertiary = ObsidianBlack,
    background = ObsidianBlack,
    onBackground = TextWhite,
    surface = ObsidianSurface,
    onSurface = TextWhite,
    surfaceVariant = ObsidianCard,
    onSurfaceVariant = TextMuted,
    outline = ObsidianBorder,
    outlineVariant = Color(0xFF423B22),
    error = ErrorRed,
    onError = TextWhite
)

@Composable
fun SKMusicProTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = BlackGoldColorScheme,
        typography = Typography,
        content = content
    )
}

// Keep backward compatible alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    SKMusicProTheme(content = content)
}
