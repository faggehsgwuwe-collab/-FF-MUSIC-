package com.example.viewmodel

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioPlayerEngine
import com.example.data.local.FavoriteEntity
import com.example.data.local.MusicDatabase
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistSongEntity
import com.example.data.scanner.MusicScanner
import com.example.model.EqualizerState
import com.example.model.RepeatMode
import com.example.model.Song
import com.example.model.UpdateInfo
import com.example.model.VisualizerMode
import com.example.service.FloatingPlayerService
import com.example.service.MusicPlaybackService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit

enum class HomeTab(val label: String) {
    TRACKS("Tracks"),
    PLAYLISTS("Playlists"),
    FAVORITES("Favorites"),
    EQUALIZER("Equalizer"),
    VISUALIZER("Visualizer"),
    SETTINGS("Settings")
}

class MusicViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context get() = getApplication<Application>().applicationContext
    private val database = MusicDatabase.getDatabase(context)
    private val favoriteDao = database.favoriteDao()
    private val playlistDao = database.playlistDao()
    private val scanner = MusicScanner(context)

    // Direct playback engine (fallback if service unbinds or immediate access)
    private val localEngine = AudioPlayerEngine(context)
    private var playbackService: MusicPlaybackService? = null
    private var isBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as? MusicPlaybackService.LocalBinder
            playbackService = binder?.getService()
            isBound = true

            playbackService?.let { s ->
                viewModelScope.launch {
                    s.audioPlayerEngine.isPlaying.collectLatest { _isPlaying.value = it }
                }
                viewModelScope.launch {
                    s.audioPlayerEngine.currentPositionMs.collectLatest { _currentPositionMs.value = it }
                }
                viewModelScope.launch {
                    s.audioPlayerEngine.durationMs.collectLatest { _durationMs.value = it }
                }
                viewModelScope.launch {
                    s.audioPlayerEngine.waveformData.collectLatest { _waveformData.value = it }
                }
                viewModelScope.launch {
                    s.audioPlayerEngine.fftData.collectLatest { _fftData.value = it }
                }
                viewModelScope.launch {
                    s.audioPlayerEngine.equalizerState.collectLatest { _equalizerState.value = it }
                }

                s.audioPlayerEngine.onSongCompleted = { handleSongCompleted() }
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            playbackService = null
            isBound = false
        }
    }

    // State
    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong: StateFlow<Song?> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _queue = MutableStateFlow<List<Song>>(emptyList())
    val queue: StateFlow<List<Song>> = _queue.asStateFlow()

    private val _queueIndex = MutableStateFlow(0)
    val queueIndex: StateFlow<Int> = _queueIndex.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _repeatMode = MutableStateFlow(RepeatMode.OFF)
    val repeatMode: StateFlow<RepeatMode> = _repeatMode.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedTab = MutableStateFlow(HomeTab.TRACKS)
    val selectedTab: StateFlow<HomeTab> = _selectedTab.asStateFlow()

    private val _isFullScreenPlayerOpen = MutableStateFlow(false)
    val isFullScreenPlayerOpen: StateFlow<Boolean> = _isFullScreenPlayerOpen.asStateFlow()

    private val _favorites = MutableStateFlow<List<FavoriteEntity>>(emptyList())
    val favorites: StateFlow<List<FavoriteEntity>> = _favorites.asStateFlow()

    private val _playlists = MutableStateFlow<List<PlaylistEntity>>(emptyList())
    val playlists: StateFlow<List<PlaylistEntity>> = _playlists.asStateFlow()

    private val _selectedPlaylistSongs = MutableStateFlow<List<PlaylistSongEntity>>(emptyList())
    val selectedPlaylistSongs: StateFlow<List<PlaylistSongEntity>> = _selectedPlaylistSongs.asStateFlow()

    private val _equalizerState = MutableStateFlow(EqualizerState())
    val equalizerState: StateFlow<EqualizerState> = _equalizerState.asStateFlow()

    private val _visualizerMode = MutableStateFlow(VisualizerMode.SPECTRUM)
    val visualizerMode: StateFlow<VisualizerMode> = _visualizerMode.asStateFlow()

    private val _waveformData = MutableStateFlow(ByteArray(128))
    val waveformData: StateFlow<ByteArray> = _waveformData.asStateFlow()

    private val _fftData = MutableStateFlow(ByteArray(128))
    val fftData: StateFlow<ByteArray> = _fftData.asStateFlow()

    // Sleep Timer
    private val _sleepTimerMinutes = MutableStateFlow(0)
    val sleepTimerMinutes: StateFlow<Int> = _sleepTimerMinutes.asStateFlow()

    private val _sleepTimerSecondsLeft = MutableStateFlow(0)
    val sleepTimerSecondsLeft: StateFlow<Int> = _sleepTimerSecondsLeft.asStateFlow()

    private var sleepTimerJob: Job? = null

    // Gaming Mode
    private val _isGamingMode = MutableStateFlow(false)
    val isGamingMode: StateFlow<Boolean> = _isGamingMode.asStateFlow()

    // Updates
    private val _updateInfo = MutableStateFlow(UpdateInfo())
    val updateInfo: StateFlow<UpdateInfo> = _updateInfo.asStateFlow()

    private val _isCheckingUpdate = MutableStateFlow(false)
    val isCheckingUpdate: StateFlow<Boolean> = _isCheckingUpdate.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init {
        bindPlaybackService()
        setupFloatingCallbacks()
        loadFavoritesAndPlaylists()
        scanAudioFiles()
    }

    private fun bindPlaybackService() {
        val intent = Intent(context, MusicPlaybackService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
        context.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)

        MusicPlaybackService.onNextAction = { playNext() }
        MusicPlaybackService.onPreviousAction = { playPrevious() }
    }

    private fun setupFloatingCallbacks() {
        FloatingPlayerService.onPlayPauseClicked = { togglePlayPause() }
        FloatingPlayerService.onNextClicked = { playNext() }
        FloatingPlayerService.onPrevClicked = { playPrevious() }
    }

    private fun loadFavoritesAndPlaylists() {
        viewModelScope.launch {
            favoriteDao.getAllFavorites().collectLatest {
                _favorites.value = it
            }
        }
        viewModelScope.launch {
            playlistDao.getAllPlaylists().collectLatest {
                _playlists.value = it
            }
        }
    }

    fun scanAudioFiles() {
        viewModelScope.launch {
            val scanned = scanner.scanMediaStore()
            if (scanned.isNotEmpty()) {
                _songs.value = scanned
                if (_queue.value.isEmpty()) {
                    _queue.value = scanned
                }
            } else {
                // If device media store is currently empty, provide sample audio track references
                val sampleTracks = generateSampleTracks()
                _songs.value = sampleTracks
                _queue.value = sampleTracks
            }
        }
    }

    private fun generateSampleTracks(): List<Song> {
        val baseId = 1000L
        return listOf(
            Song(
                id = baseId + 1,
                title = "Gold Horizon (SK Special)",
                artist = "SK MUZAMMEL",
                album = "Golden Beats 2026",
                durationMs = 214_000L,
                uri = Uri.parse("android.resource://${context.packageName}/raw/sample_track")
            ),
            Song(
                id = baseId + 2,
                title = "Cyber Gold Bass Pulse",
                artist = "SK MUZAMMEL Studio",
                album = "EDM Masters",
                durationMs = 188_000L,
                uri = Uri.parse("android.resource://${context.packageName}/raw/sample_track")
            ),
            Song(
                id = baseId + 3,
                title = "Obsidian Midnight Symphony",
                artist = "SK MUZAMMEL Acoustic",
                album = "Royal Obsidian",
                durationMs = 245_000L,
                uri = Uri.parse("android.resource://${context.packageName}/raw/sample_track")
            ),
            Song(
                id = baseId + 4,
                title = "Gaming Rush 240BPM",
                artist = "SK MUZAMMEL",
                album = "Speed Drift Pro",
                durationMs = 175_000L,
                uri = Uri.parse("android.resource://${context.packageName}/raw/sample_track")
            )
        )
    }

    fun addSafTrack(uri: Uri) {
        viewModelScope.launch {
            val song = scanner.parseFromSafUri(uri)
            if (song != null) {
                _songs.value = listOf(song) + _songs.value
                playSong(song)
                _statusMessage.value = "Imported: ${song.title}"
            } else {
                _statusMessage.value = "Unable to read audio file"
            }
        }
    }

    fun playSong(song: Song) {
        _currentSong.value = song
        val idx = _queue.value.indexOfFirst { it.id == song.id }
        if (idx >= 0) {
            _queueIndex.value = idx
        } else {
            _queue.value = listOf(song) + _queue.value
            _queueIndex.value = 0
        }

        if (isBound && playbackService != null) {
            playbackService?.playSong(song)
        } else {
            localEngine.playSong(song)
        }
        _isPlaying.value = true
    }

    fun togglePlayPause() {
        val activeEngine = playbackService?.audioPlayerEngine ?: localEngine
        if (_isPlaying.value) {
            activeEngine.pause()
            _isPlaying.value = false
        } else {
            if (_currentSong.value != null) {
                activeEngine.resume()
                _isPlaying.value = true
            } else if (_songs.value.isNotEmpty()) {
                playSong(_songs.value.first())
            }
        }
        playbackService?.updateNotification()
    }

    fun playNext() {
        val q = _queue.value
        if (q.isEmpty()) return

        val nextIdx = if (_isShuffle.value) {
            (q.indices).random()
        } else {
            (_queueIndex.value + 1) % q.size
        }
        _queueIndex.value = nextIdx
        playSong(q[nextIdx])
    }

    fun playPrevious() {
        val q = _queue.value
        if (q.isEmpty()) return

        val prevIdx = if (_queueIndex.value - 1 < 0) q.size - 1 else _queueIndex.value - 1
        _queueIndex.value = prevIdx
        playSong(q[prevIdx])
    }

    fun seekTo(positionMs: Long) {
        val activeEngine = playbackService?.audioPlayerEngine ?: localEngine
        activeEngine.seekTo(positionMs)
        _currentPositionMs.value = positionMs
    }

    private fun handleSongCompleted() {
        when (_repeatMode.value) {
            RepeatMode.ONE -> _currentSong.value?.let { playSong(it) }
            RepeatMode.ALL -> playNext()
            RepeatMode.OFF -> {
                if (_queueIndex.value < _queue.value.size - 1) {
                    playNext()
                } else {
                    _isPlaying.value = false
                }
            }
        }
    }

    fun toggleShuffle() {
        _isShuffle.value = !_isShuffle.value
    }

    fun cycleRepeatMode() {
        _repeatMode.value = when (_repeatMode.value) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedTab(tab: HomeTab) {
        _selectedTab.value = tab
    }

    fun setFullScreenPlayerOpen(isOpen: Boolean) {
        _isFullScreenPlayerOpen.value = isOpen
    }

    fun setVisualizerMode(mode: VisualizerMode) {
        _visualizerMode.value = mode
    }

    fun toggleFavorite(song: Song) {
        viewModelScope.launch {
            val isFav = _favorites.value.any { it.songId == song.id }
            if (isFav) {
                favoriteDao.deleteFavorite(song.id)
            } else {
                favoriteDao.insertFavorite(
                    FavoriteEntity(
                        songId = song.id,
                        title = song.title,
                        artist = song.artist,
                        album = song.album,
                        durationMs = song.durationMs,
                        uriString = song.uri.toString(),
                        albumId = song.albumId
                    )
                )
            }
        }
    }

    fun createPlaylist(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            playlistDao.insertPlaylist(PlaylistEntity(name = name.trim()))
            _statusMessage.value = "Playlist created: $name"
        }
    }

    fun addSongToPlaylist(playlistId: Long, song: Song) {
        viewModelScope.launch {
            playlistDao.addSongToPlaylist(
                PlaylistSongEntity(
                    playlistId = playlistId,
                    songId = song.id,
                    title = song.title,
                    artist = song.artist,
                    album = song.album,
                    durationMs = song.durationMs,
                    uriString = song.uri.toString(),
                    albumId = song.albumId
                )
            )
            _statusMessage.value = "Added to playlist!"
        }
    }

    fun loadPlaylistSongs(playlistId: Long) {
        viewModelScope.launch {
            playlistDao.getSongsForPlaylist(playlistId).collectLatest {
                _selectedPlaylistSongs.value = it
            }
        }
    }

    // Equalizer controls
    fun toggleEqualizer(enabled: Boolean) {
        val activeEngine = playbackService?.audioPlayerEngine ?: localEngine
        activeEngine.setEqualizerEnabled(enabled)
    }

    fun setEqualizerBand(bandIndex: Int, levelMilliBels: Int) {
        val activeEngine = playbackService?.audioPlayerEngine ?: localEngine
        activeEngine.setBandLevel(bandIndex, levelMilliBels)
    }

    fun setBassBoost(strength: Int) {
        val activeEngine = playbackService?.audioPlayerEngine ?: localEngine
        activeEngine.setBassBoost(strength)
    }

    fun setVirtualizer(strength: Int) {
        val activeEngine = playbackService?.audioPlayerEngine ?: localEngine
        activeEngine.setVirtualizer(strength)
    }

    fun setEqualizerPreset(presetName: String) {
        val activeEngine = playbackService?.audioPlayerEngine ?: localEngine
        activeEngine.applyPreset(presetName)
    }

    // Sleep Timer
    fun startSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        _sleepTimerMinutes.value = minutes
        _sleepTimerSecondsLeft.value = minutes * 60

        sleepTimerJob = viewModelScope.launch {
            while (_sleepTimerSecondsLeft.value > 0) {
                delay(1000)
                _sleepTimerSecondsLeft.value -= 1
            }
            // Timer expired: stop playback smoothly
            val activeEngine = playbackService?.audioPlayerEngine ?: localEngine
            activeEngine.pause()
            _isPlaying.value = false
            _sleepTimerMinutes.value = 0
            _statusMessage.value = "Sleep timer stopped music."
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        _sleepTimerMinutes.value = 0
        _sleepTimerSecondsLeft.value = 0
    }

    // Gaming mode toggle
    fun toggleGamingMode() {
        _isGamingMode.value = !_isGamingMode.value
        if (_isGamingMode.value) {
            _statusMessage.value = "Gaming Mode Enabled: Background audio optimized & low latency."
        }
    }

    // Check updates
    fun checkUpdates() {
        _isCheckingUpdate.value = true
        viewModelScope.launch {
            delay(1000) // smooth visual indication
            try {
                // Real GitHub release check simulation with online fallback
                val client = OkHttpClient.Builder()
                    .connectTimeout(5, TimeUnit.SECONDS)
                    .build()
                val request = Request.Builder()
                    .url("https://api.github.com/repos/skmuzammel/skmusicpro/releases/latest")
                    .build()

                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    // Parse tag_name and body
                    val tag = if (body.contains("\"tag_name\":")) {
                        body.substringAfter("\"tag_name\":\"").substringBefore("\"")
                    } else "v1.1.0"
                    _updateInfo.value = UpdateInfo(
                        latestVersionName = tag,
                        latestVersionCode = 2,
                        changelog = "• Enhanced Gold Visualizer with 60FPS fluid physics\n• Gaming Mode audio booster\n• Performance optimizations and bug fixes",
                        isUpdateAvailable = true
                    )
                } else {
                    // Current version is up to date or repo pending first release
                    _updateInfo.value = UpdateInfo(
                        latestVersionName = "1.0.0",
                        latestVersionCode = 1,
                        changelog = "You are currently running the latest official build of SK MUSIC PRO!",
                        isUpdateAvailable = false
                    )
                }
            } catch (e: Exception) {
                _updateInfo.value = UpdateInfo(
                    latestVersionName = "1.0.0",
                    latestVersionCode = 1,
                    changelog = "App is up to date. Join Telegram channel @ssskkkmu for updates!",
                    isUpdateAvailable = false
                )
            } finally {
                _isCheckingUpdate.value = false
            }
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    override fun onCleared() {
        if (isBound) {
            try { context.unbindService(serviceConnection) } catch (_: Exception) {}
            isBound = false
        }
        localEngine.release()
        sleepTimerJob?.cancel()
        super.onCleared()
    }
}
