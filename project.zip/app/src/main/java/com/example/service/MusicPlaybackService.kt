package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.audio.AudioPlayerEngine
import com.example.model.Song

class MusicPlaybackService : Service() {

    private val binder = LocalBinder()
    lateinit var audioPlayerEngine: AudioPlayerEngine
        private set

    private var mediaSession: MediaSession? = null
    private var notificationManager: NotificationManager? = null
    private var currentSong: Song? = null

    private var isNoisyReceiverRegistered = false
    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
                audioPlayerEngine.pause()
                updateNotification()
            }
        }
    }

    inner class LocalBinder : Binder() {
        fun getService(): MusicPlaybackService = this@MusicPlaybackService
    }

    override fun onCreate() {
        super.onCreate()
        audioPlayerEngine = AudioPlayerEngine(this)
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel()
        initMediaSession()

        val filter = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
        registerReceiver(noisyReceiver, filter)
        isNoisyReceiverRegistered = true
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SK Music Playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background playback controls for SK MUSIC PRO"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            notificationManager?.createNotificationChannel(channel)
        }
    }

    private fun initMediaSession() {
        mediaSession = MediaSession(this, "SKMusicProSession").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() {
                    audioPlayerEngine.resume()
                    updateNotification()
                }

                override fun onPause() {
                    audioPlayerEngine.pause()
                    updateNotification()
                }

                override fun onSkipToNext() {
                    onNextAction?.invoke()
                }

                override fun onSkipToPrevious() {
                    onPreviousAction?.invoke()
                }

                override fun onSeekTo(pos: Long) {
                    audioPlayerEngine.seekTo(pos)
                }

                override fun onStop() {
                    audioPlayerEngine.pause()
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            })
            isActive = true
        }
    }

    fun playSong(song: Song) {
        currentSong = song
        audioPlayerEngine.playSong(song)
        updateMediaSession(song)
        startForeground(NOTIFICATION_ID, buildNotification(song, true))
    }

    fun updateMediaSession(song: Song) {
        val stateBuilder = PlaybackState.Builder()
            .setActions(
                PlaybackState.ACTION_PLAY or
                PlaybackState.ACTION_PAUSE or
                PlaybackState.ACTION_SKIP_TO_NEXT or
                PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                PlaybackState.ACTION_SEEK_TO
            )
            .setState(
                if (audioPlayerEngine.isPlaying.value) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                audioPlayerEngine.currentPositionMs.value,
                1.0f
            )
        mediaSession?.setPlaybackState(stateBuilder.build())

        val metadataBuilder = MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, song.title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, song.artist)
            .putString(MediaMetadata.METADATA_KEY_ALBUM, song.album)
            .putLong(MediaMetadata.METADATA_KEY_DURATION, song.durationMs)
        mediaSession?.setMetadata(metadataBuilder.build())
    }

    fun updateNotification() {
        currentSong?.let { song ->
            val isPlaying = audioPlayerEngine.isPlaying.value
            updateMediaSession(song)
            val notification = buildNotification(song, isPlaying)
            notificationManager?.notify(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(song: Song, isPlaying: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val prevIntent = Intent(this, MusicPlaybackService::class.java).apply { action = ACTION_PREV }
        val prevPending = PendingIntent.getService(this, 1, prevIntent, PendingIntent.FLAG_IMMUTABLE)

        val playPauseIntent = Intent(this, MusicPlaybackService::class.java).apply {
            action = if (isPlaying) ACTION_PAUSE else ACTION_PLAY
        }
        val playPausePending = PendingIntent.getService(this, 2, playPauseIntent, PendingIntent.FLAG_IMMUTABLE)

        val nextIntent = Intent(this, MusicPlaybackService::class.java).apply { action = ACTION_NEXT }
        val nextPending = PendingIntent.getService(this, 3, nextIntent, PendingIntent.FLAG_IMMUTABLE)

        val closeIntent = Intent(this, MusicPlaybackService::class.java).apply { action = ACTION_STOP }
        val closePending = PendingIntent.getService(this, 4, closeIntent, PendingIntent.FLAG_IMMUTABLE)

        val defaultArt = BitmapFactory.decodeResource(resources, R.drawable.sk_music_logo_1793468786611)

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setLargeIcon(defaultArt)
            .setContentTitle(song.title)
            .setContentText("${song.artist} • ${song.album}")
            .setSubText("SK MUSIC PRO")
            .setContentIntent(contentPendingIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(isPlaying)
            .addAction(android.R.drawable.ic_media_previous, "Prev", prevPending)
            .addAction(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (isPlaying) "Pause" else "Play",
                playPausePending
            )
            .addAction(android.R.drawable.ic_media_next, "Next", nextPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", closePending)

        return builder.build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                audioPlayerEngine.resume()
                updateNotification()
            }
            ACTION_PAUSE -> {
                audioPlayerEngine.pause()
                updateNotification()
            }
            ACTION_NEXT -> onNextAction?.invoke()
            ACTION_PREV -> onPreviousAction?.invoke()
            ACTION_STOP -> {
                audioPlayerEngine.pause()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        if (isNoisyReceiverRegistered) {
            try { unregisterReceiver(noisyReceiver) } catch (_: Exception) {}
            isNoisyReceiverRegistered = false
        }
        mediaSession?.release()
        audioPlayerEngine.release()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "sk_music_pro_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_PLAY = "com.skmuzammel.ACTION_PLAY"
        const val ACTION_PAUSE = "com.skmuzammel.ACTION_PAUSE"
        const val ACTION_NEXT = "com.skmuzammel.ACTION_NEXT"
        const val ACTION_PREV = "com.skmuzammel.ACTION_PREV"
        const val ACTION_STOP = "com.skmuzammel.ACTION_STOP"

        var onNextAction: (() -> Unit)? = null
        var onPreviousAction: (() -> Unit)? = null
    }
}
