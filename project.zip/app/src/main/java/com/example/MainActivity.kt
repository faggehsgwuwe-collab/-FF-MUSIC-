package com.example

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.Song
import com.example.model.VisualizerMode
import com.example.ui.components.AddToPlaylistDialog
import com.example.ui.components.FullScreenPlayerSheet
import com.example.ui.components.MiniPlayer
import com.example.ui.components.PermissionWizardDialog
import com.example.ui.screens.EqualizerScreen
import com.example.ui.screens.FavoritesTab
import com.example.ui.screens.PlaylistsTab
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TracksTab
import com.example.ui.screens.VisualizerScreen
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.SKMusicProTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.util.PermissionActionType
import com.example.util.PermissionManager
import com.example.viewmodel.HomeTab
import com.example.viewmodel.MusicViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SKMusicProTheme {
                MainAppScreen(
                    intentUri = intent?.data,
                    onOpenSettings = { PermissionManager.openAppSettings(this) },
                    onOpenOverlaySettings = { PermissionManager.openOverlaySettings(this) }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    intentUri: Uri? = null,
    onOpenSettings: () -> Unit,
    onOpenOverlaySettings: () -> Unit,
    vm: MusicViewModel = viewModel()
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    // UI States
    val songs by vm.songs.collectAsState()
    val currentSong by vm.currentSong.collectAsState()
    val isPlaying by vm.isPlaying.collectAsState()
    val currentPositionMs by vm.currentPositionMs.collectAsState()
    val durationMs by vm.durationMs.collectAsState()
    val isShuffle by vm.isShuffle.collectAsState()
    val repeatMode by vm.repeatMode.collectAsState()
    val searchQuery by vm.searchQuery.collectAsState()
    val selectedTab by vm.selectedTab.collectAsState()
    val isFullScreenPlayerOpen by vm.isFullScreenPlayerOpen.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val selectedPlaylistSongs by vm.selectedPlaylistSongs.collectAsState()
    val equalizerState by vm.equalizerState.collectAsState()
    val visualizerMode by vm.visualizerMode.collectAsState()
    val waveformData by vm.waveformData.collectAsState()
    val fftData by vm.fftData.collectAsState()
    val sleepTimerMinutes by vm.sleepTimerMinutes.collectAsState()
    val sleepTimerSecondsLeft by vm.sleepTimerSecondsLeft.collectAsState()
    val isGamingMode by vm.isGamingMode.collectAsState()
    val updateInfo by vm.updateInfo.collectAsState()
    val isCheckingUpdate by vm.isCheckingUpdate.collectAsState()
    val statusMessage by vm.statusMessage.collectAsState()

    var showPermissionWizard by remember {
        mutableStateOf(!PermissionManager.checkAudioPermission(context))
    }
    var pendingPlaylistSong by remember { mutableStateOf<Song?>(null) }

    // Permission launchers
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.values.any { it }
        if (granted) {
            vm.scanAudioFiles()
            Toast.makeText(context, "Storage access granted! Scanning music...", Toast.LENGTH_SHORT).show()
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            Toast.makeText(context, "Notifications enabled for lockscreen controls", Toast.LENGTH_SHORT).show()
        }
    }

    val recordAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            Toast.makeText(context, "Visualizer hardware access enabled", Toast.LENGTH_SHORT).show()
        }
    }

    val permissionHandler: (PermissionActionType) -> Unit = { actionType ->
        when (actionType) {
            PermissionActionType.RUNTIME_AUDIO -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    audioPermissionLauncher.launch(arrayOf(Manifest.permission.READ_MEDIA_AUDIO))
                } else {
                    audioPermissionLauncher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE))
                }
            }
            PermissionActionType.RUNTIME_NOTIFICATIONS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            PermissionActionType.RUNTIME_RECORD_AUDIO -> {
                recordAudioLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
            PermissionActionType.SYSTEM_OVERLAY_SETTINGS -> {
                onOpenOverlaySettings()
            }
            PermissionActionType.APP_SETTINGS -> {
                onOpenSettings()
            }
        }
    }

    // Handle initial intent audio uri
    LaunchedEffect(intentUri) {
        intentUri?.let { vm.addSafTrack(it) }
    }

    // Status snackbar
    LaunchedEffect(statusMessage) {
        statusMessage?.let {
            snackbarHostState.showSnackbar(it)
            vm.clearStatusMessage()
        }
    }

    // Back handling for FullScreenPlayerSheet
    BackHandler(enabled = isFullScreenPlayerOpen) {
        vm.setFullScreenPlayerOpen(false)
    }

    val favoriteIds = remember(favorites) { favorites.map { it.songId }.toSet() }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (!isFullScreenPlayerOpen) {
                AppTopBar(
                    onScanClick = {
                        if (PermissionManager.checkAudioPermission(context)) {
                            vm.scanAudioFiles()
                        } else {
                            permissionHandler(PermissionActionType.RUNTIME_AUDIO)
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (!isFullScreenPlayerOpen) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    // Mini Player docked right above bottom navigation
                    MiniPlayer(
                        song = currentSong,
                        isPlaying = isPlaying,
                        currentPositionMs = currentPositionMs,
                        durationMs = durationMs,
                        onPlayPauseClick = { vm.togglePlayPause() },
                        onNextClick = { vm.playNext() },
                        onExpandClick = { vm.setFullScreenPlayerOpen(true) }
                    )

                    // Navigation Bar
                    NavigationBar(
                        containerColor = ObsidianSurface,
                        contentColor = TextWhite
                    ) {
                        HomeTab.values().forEach { tab ->
                            val isSelected = selectedTab == tab
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { vm.setSelectedTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = getTabIcon(tab),
                                        contentDescription = tab.label
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ObsidianBlack,
                                    selectedTextColor = GoldSecondary,
                                    indicatorColor = GoldPrimary,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted
                                )
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                HomeTab.TRACKS -> TracksTab(
                    songs = songs,
                    currentSong = currentSong,
                    isPlaying = isPlaying,
                    favoriteIds = favoriteIds,
                    searchQuery = searchQuery,
                    onSearchQueryChange = { vm.setSearchQuery(it) },
                    onSongClick = { vm.playSong(it) },
                    onToggleFavorite = { vm.toggleFavorite(it) },
                    onAddToPlaylist = { pendingPlaylistSong = it },
                    onScanClick = {
                        if (PermissionManager.checkAudioPermission(context)) {
                            vm.scanAudioFiles()
                        } else {
                            permissionHandler(PermissionActionType.RUNTIME_AUDIO)
                        }
                    },
                    onImportSaf = { vm.addSafTrack(it) },
                    onShuffleAll = {
                        vm.toggleShuffle()
                        if (songs.isNotEmpty()) vm.playSong(songs.random())
                    }
                )

                HomeTab.PLAYLISTS -> PlaylistsTab(
                    playlists = playlists,
                    selectedPlaylistSongs = selectedPlaylistSongs,
                    currentSong = currentSong,
                    isPlaying = isPlaying,
                    favoriteIds = favoriteIds,
                    onCreatePlaylist = { vm.createPlaylist(it) },
                    onSelectPlaylist = { vm.loadPlaylistSongs(it) },
                    onSongClick = { vm.playSong(it) },
                    onToggleFavorite = { vm.toggleFavorite(it) }
                )

                HomeTab.FAVORITES -> FavoritesTab(
                    favorites = favorites,
                    currentSong = currentSong,
                    isPlaying = isPlaying,
                    onSongClick = { vm.playSong(it) },
                    onToggleFavorite = { vm.toggleFavorite(it) },
                    onPlayAll = {
                        if (favorites.isNotEmpty()) {
                            val first = favorites.first()
                            vm.playSong(
                                Song(
                                    id = first.songId,
                                    title = first.title,
                                    artist = first.artist,
                                    album = first.album,
                                    durationMs = first.durationMs,
                                    uri = Uri.parse(first.uriString),
                                    albumId = first.albumId
                                )
                            )
                        }
                    }
                )

                HomeTab.EQUALIZER -> EqualizerScreen(
                    equalizerState = equalizerState,
                    onToggleEnabled = { vm.toggleEqualizer(it) },
                    onBandChange = { bandIdx, level -> vm.setEqualizerBand(bandIdx, level) },
                    onBassBoostChange = { vm.setBassBoost(it) },
                    onVirtualizerChange = { vm.setVirtualizer(it) },
                    onPresetSelected = { vm.setEqualizerPreset(it) }
                )

                HomeTab.VISUALIZER -> VisualizerScreen(
                    currentSong = currentSong,
                    isPlaying = isPlaying,
                    waveformData = waveformData,
                    fftData = fftData,
                    selectedMode = visualizerMode,
                    onModeSelect = { vm.setVisualizerMode(it) }
                )

                HomeTab.SETTINGS -> SettingsScreen(
                    isGamingMode = isGamingMode,
                    onToggleGamingMode = { vm.toggleGamingMode() },
                    sleepTimerMinutes = sleepTimerMinutes,
                    sleepTimerSecondsLeft = sleepTimerSecondsLeft,
                    onSetSleepTimer = { vm.startSleepTimer(it) },
                    onCancelSleepTimer = { vm.cancelSleepTimer() },
                    updateInfo = updateInfo,
                    isCheckingUpdate = isCheckingUpdate,
                    onCheckUpdate = { vm.checkUpdates() },
                    onRequestPermission = permissionHandler
                )
            }
        }

        // Full Screen Player Overlay Modal
        AnimatedVisibility(
            visible = isFullScreenPlayerOpen,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            FullScreenPlayerSheet(
                song = currentSong,
                isPlaying = isPlaying,
                currentPositionMs = currentPositionMs,
                durationMs = durationMs,
                isShuffle = isShuffle,
                repeatMode = repeatMode,
                isFavorite = currentSong?.let { favoriteIds.contains(it.id) } == true,
                waveformData = waveformData,
                fftData = fftData,
                onPlayPauseClick = { vm.togglePlayPause() },
                onNextClick = { vm.playNext() },
                onPrevClick = { vm.playPrevious() },
                onSeek = { vm.seekTo(it) },
                onToggleShuffle = { vm.toggleShuffle() },
                onCycleRepeat = { vm.cycleRepeatMode() },
                onToggleFavorite = { currentSong?.let { vm.toggleFavorite(it) } },
                onOpenEqualizer = {
                    vm.setFullScreenPlayerOpen(false)
                    vm.setSelectedTab(HomeTab.EQUALIZER)
                },
                onOpenVisualizer = {
                    vm.setFullScreenPlayerOpen(false)
                    vm.setSelectedTab(HomeTab.VISUALIZER)
                },
                onOpenSleepTimer = {
                    vm.setFullScreenPlayerOpen(false)
                    vm.setSelectedTab(HomeTab.SETTINGS)
                },
                onClose = { vm.setFullScreenPlayerOpen(false) }
            )
        }

        // Permission Wizard on initial launch
        if (showPermissionWizard) {
            PermissionWizardDialog(
                permissionStatuses = PermissionManager.getAllStatuses(context),
                onRequestPermission = permissionHandler,
                onDismiss = { showPermissionWizard = false }
            )
        }

        // Add to Playlist Dialog
        pendingPlaylistSong?.let { song ->
            AddToPlaylistDialog(
                song = song,
                playlists = playlists,
                onSelectPlaylist = { playlistId ->
                    vm.addSongToPlaylist(playlistId, song)
                    pendingPlaylistSong = null
                },
                onCreateNewPlaylist = { name ->
                    vm.createPlaylist(name)
                },
                onDismiss = { pendingPlaylistSong = null }
            )
        }
    }
}

@Composable
fun AppTopBar(onScanClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .background(ObsidianBlack)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(GoldPrimary.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = GoldSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "SK MUSIC PRO",
                    color = GoldSecondary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "BY SK MUZAMMEL",
                    color = GoldDark,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

private fun getTabIcon(tab: HomeTab): ImageVector {
    return when (tab) {
        HomeTab.TRACKS -> Icons.Default.MusicNote
        HomeTab.PLAYLISTS -> Icons.Default.QueueMusic
        HomeTab.FAVORITES -> Icons.Default.Favorite
        HomeTab.EQUALIZER -> Icons.Default.Equalizer
        HomeTab.VISUALIZER -> Icons.Default.GraphicEq
        HomeTab.SETTINGS -> Icons.Default.Settings
    }
}
