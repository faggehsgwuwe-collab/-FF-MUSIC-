package com.example.model

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri,
    val albumId: Long = -1,
    val albumArtUri: Uri? = null,
    val size: Long = 0,
    val mimeType: String = "audio/mpeg",
    val path: String = "",
    val isFavorite: Boolean = false
) {
    val durationFormatted: String
        get() {
            val totalSeconds = durationMs / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return "%d:%02d".format(minutes, seconds)
        }
}

enum class RepeatMode {
    OFF,
    ALL,
    ONE
}

enum class VisualizerMode(val displayName: String) {
    SPECTRUM("Spectrum Bars"),
    WAVEFORM("Liquid Waveform"),
    BASS_PULSE("Bass Pulse Aura"),
    CIRCULAR("Circular Radial")
}

data class EqualizerBand(
    val index: Int,
    val centerFreqHz: Int,
    val minLevelMilliBels: Int,
    val maxLevelMilliBels: Int,
    var currentLevelMilliBels: Int
) {
    val centerFreqFormatted: String
        get() = if (centerFreqHz >= 1000) "${centerFreqHz / 1000} kHz" else "$centerFreqHz Hz"
}

data class EqualizerState(
    val isEnabled: Boolean = true,
    val bassBoost: Int = 300,        // 0 to 1000
    val virtualizer: Int = 200,      // 0 to 1000
    val treble: Int = 0,             // -1000 to 1000
    val currentPreset: String = "Normal",
    val bands: List<EqualizerBand> = emptyList()
)

data class UpdateInfo(
    val latestVersionName: String = "1.0.0",
    val latestVersionCode: Int = 1,
    val changelog: String = "",
    val downloadUrl: String = "https://github.com/skmuzammel/skmusicpro/releases",
    val isUpdateAvailable: Boolean = false
)
