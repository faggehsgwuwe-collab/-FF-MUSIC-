package com.example.util

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat

data class PermissionStatus(
    val id: String,
    val title: String,
    val titleBengali: String,
    val descriptionBengali: String,
    val isGranted: Boolean,
    val isRequired: Boolean,
    val actionType: PermissionActionType
)

enum class PermissionActionType {
    RUNTIME_AUDIO,
    RUNTIME_NOTIFICATIONS,
    RUNTIME_RECORD_AUDIO,
    SYSTEM_OVERLAY_SETTINGS,
    APP_SETTINGS
}

object PermissionManager {

    fun checkAudioPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_MEDIA_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun checkNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    fun checkOverlayPermission(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }

    fun checkRecordAudioPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun getAllStatuses(context: Context): List<PermissionStatus> {
        return listOf(
            PermissionStatus(
                id = "audio",
                title = "Music Storage Access",
                titleBengali = "গান ও অডিও অ্যাক্সেস",
                descriptionBengali = "ফোনের মেমোরি থেকে আপনার প্রিয় MP3, FLAC গানগুলো স্ক্যান ও প্লে করার জন্য প্রয়োজন।",
                isGranted = checkAudioPermission(context),
                isRequired = true,
                actionType = PermissionActionType.RUNTIME_AUDIO
            ),
            PermissionStatus(
                id = "notifications",
                title = "Media Notifications",
                titleBengali = "নোটিফিকেশন ও লকস্ক্রিন কন্ট্রোল",
                descriptionBengali = "লকস্ক্রিন এবং নোটিফিকেশন বারে প্লে, পজ, নেক্সট বাটন প্রদর্শন করতে প্রয়োজন (Android 13+)।",
                isGranted = checkNotificationPermission(context),
                isRequired = false,
                actionType = PermissionActionType.RUNTIME_NOTIFICATIONS
            ),
            PermissionStatus(
                id = "overlay",
                title = "Floating Player (Display over apps)",
                titleBengali = "ফ্লোটিং উইন্ডো (অন্য অ্যাপের উপর প্রদর্শন)",
                descriptionBengali = "গেম খেলা বা অন্যান্য অ্যাপ ব্যবহারের সময় স্ক্রিনে মিনি মিউজিক কন্ট্রোলার ভাসিয়ে রাখতে প্রয়োজন।",
                isGranted = checkOverlayPermission(context),
                isRequired = false,
                actionType = PermissionActionType.SYSTEM_OVERLAY_SETTINGS
            ),
            PermissionStatus(
                id = "visualizer",
                title = "Audio FX & Visualizer",
                titleBengali = "অডিও বিট ভিজ্যুয়ালাইজার",
                descriptionBengali = "গানের রিয়েল-টাইম ফ্রিকোয়েন্সি ও স্পেকট্রাম ওয়েভফর্ম অ্যানিমেশনের জন্য (কোনো ভয়েস রেকর্ড করা হয় না)।",
                isGranted = checkRecordAudioPermission(context),
                isRequired = false,
                actionType = PermissionActionType.RUNTIME_RECORD_AUDIO
            )
        )
    }

    fun openOverlaySettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try { context.startActivity(intent) } catch (_: Exception) {}
    }

    fun openAppSettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${context.packageName}")
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try { context.startActivity(intent) } catch (_: Exception) {}
    }
}
