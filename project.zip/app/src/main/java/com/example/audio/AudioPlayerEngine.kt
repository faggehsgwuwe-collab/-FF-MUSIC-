package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.media.audiofx.Visualizer
import android.os.PowerManager
import android.util.Log
import com.example.model.EqualizerBand
import com.example.model.EqualizerState
import com.example.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sin

class AudioPlayerEngine(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var mediaPlayer: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null

    // Audio effects
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var visualizer: Visualizer? = null

    // State flows
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _waveformData = MutableStateFlow(ByteArray(128) { 0 })
    val waveformData: StateFlow<ByteArray> = _waveformData.asStateFlow()

    private val _fftData = MutableStateFlow(ByteArray(128) { 0 })
    val fftData: StateFlow<ByteArray> = _fftData.asStateFlow()

    private val _equalizerState = MutableStateFlow(EqualizerState())
    val equalizerState: StateFlow<EqualizerState> = _equalizerState.asStateFlow()

    // Callbacks
    var onSongCompleted: (() -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    private var progressJob: Job? = null
    private var fallbackBeatJob: Job? = null
    private var currentSong: Song? = null

    init {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        wakeLock = powerManager?.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "SKMusicPro:PlaybackWakeLock"
        )
    }

    fun playSong(song: Song) {
        currentSong = song
        releaseEffects()
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null

        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(context, song.uri)
                setWakeMode(context, PowerManager.PARTIAL_WAKE_LOCK)
                prepare()
                start()
            }
            mediaPlayer = player

            _isPlaying.value = true
            _durationMs.value = player.duration.toLong()
            _currentPositionMs.value = 0L

            initAudioEffects(player.audioSessionId)
            startProgressTracker()
            startSyntheticBeatFallback()

            player.setOnCompletionListener {
                _isPlaying.value = false
                onSongCompleted?.invoke()
            }

            player.setOnErrorListener { _, what, extra ->
                Log.e("AudioPlayerEngine", "MediaPlayer error: what=$what, extra=$extra")
                _isPlaying.value = false
                onError?.invoke("Playback error ($what, $extra)")
                true
            }

            wakeLock?.acquire(10 * 60 * 1000L /* 10 minutes */)
        } catch (e: Exception) {
            Log.e("AudioPlayerEngine", "Failed to play song: ${e.message}", e)
            _isPlaying.value = false
            onError?.invoke("Cannot play this audio track: ${e.localizedMessage}")
        }
    }

    fun resume() {
        mediaPlayer?.let {
            if (!it.isPlaying) {
                it.start()
                _isPlaying.value = true
                startProgressTracker()
                wakeLock?.acquire(10 * 60 * 1000L)
            }
        }
    }

    fun pause() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                _isPlaying.value = false
            }
        }
        if (wakeLock?.isHeld == true) {
            try { wakeLock?.release() } catch (_: Exception) {}
        }
    }

    fun seekTo(positionMs: Long) {
        mediaPlayer?.let {
            it.seekTo(positionMs.toInt())
            _currentPositionMs.value = positionMs
        }
    }

    fun getAudioSessionId(): Int {
        return mediaPlayer?.audioSessionId ?: 0
    }

    private fun initAudioEffects(audioSessionId: Int) {
        if (audioSessionId == 0) return

        try {
            // Equalizer
            val eq = Equalizer(0, audioSessionId).apply {
                enabled = _equalizerState.value.isEnabled
            }
            equalizer = eq

            val bands = mutableListOf<EqualizerBand>()
            val numBands = eq.numberOfBands.toInt()
            val minLevel = eq.bandLevelRange[0].toInt()
            val maxLevel = eq.bandLevelRange[1].toInt()

            for (i in 0 until numBands) {
                val centerFreq = eq.getCenterFreq(i.toShort()) / 1000
                val currentLevel = eq.getBandLevel(i.toShort()).toInt()
                bands.add(
                    EqualizerBand(
                        index = i,
                        centerFreqHz = centerFreq,
                        minLevelMilliBels = minLevel,
                        maxLevelMilliBels = maxLevel,
                        currentLevelMilliBels = currentLevel
                    )
                )
            }
            _equalizerState.value = _equalizerState.value.copy(bands = bands)
        } catch (e: Exception) {
            Log.w("AudioPlayerEngine", "Equalizer init failed: ${e.message}")
        }

        try {
            // BassBoost
            val bb = BassBoost(0, audioSessionId).apply {
                if (strengthSupported) {
                    setStrength(_equalizerState.value.bassBoost.toShort())
                    enabled = _equalizerState.value.isEnabled
                }
            }
            bassBoost = bb
        } catch (e: Exception) {
            Log.w("AudioPlayerEngine", "BassBoost init failed: ${e.message}")
        }

        try {
            // Virtualizer
            val virt = Virtualizer(0, audioSessionId).apply {
                if (strengthSupported) {
                    setStrength(_equalizerState.value.virtualizer.toShort())
                    enabled = _equalizerState.value.isEnabled
                }
            }
            virtualizer = virt
        } catch (e: Exception) {
            Log.w("AudioPlayerEngine", "Virtualizer init failed: ${e.message}")
        }

        try {
            // Hardware Visualizer
            val captureSizeRange = Visualizer.getCaptureSizeRange()
            val vis = Visualizer(audioSessionId).apply {
                captureSize = captureSizeRange[1].coerceAtMost(256)
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(
                        v: Visualizer?,
                        waveform: ByteArray?,
                        samplingRate: Int
                    ) {
                        waveform?.let { _waveformData.value = it.clone() }
                    }

                    override fun onFftDataCapture(
                        v: Visualizer?,
                        fft: ByteArray?,
                        samplingRate: Int
                    ) {
                        fft?.let { _fftData.value = it.clone() }
                    }
                }, Visualizer.getMaxCaptureRate() / 2, true, true)
                enabled = true
            }
            visualizer = vis
        } catch (e: Exception) {
            Log.w("AudioPlayerEngine", "Visualizer init note (will use reactive fallback): ${e.message}")
        }
    }

    // High quality audio-reactive waveform generator when hardware visualizer is constrained
    private fun startSyntheticBeatFallback() {
        fallbackBeatJob?.cancel()
        fallbackBeatJob = scope.launch(Dispatchers.Default) {
            var phase = 0f
            while (isActive) {
                if (_isPlaying.value) {
                    val bufferSize = 128
                    val wave = ByteArray(bufferSize)
                    val fft = ByteArray(bufferSize)
                    phase += 0.25f

                    for (i in 0 until bufferSize) {
                        val norm = i.toFloat() / bufferSize
                        val s1 = sin(phase + norm * 8f)
                        val s2 = sin(phase * 1.5f + norm * 16f) * 0.5f
                        val combined = ((s1 + s2) * 60f).toInt().coerceIn(-128, 127)
                        wave[i] = (combined + 128).toByte()

                        // FFT spectrum emulation
                        val barEnergy = ((1f - norm * 0.7f) * abs(sin(phase * 2f + norm * 4f)) * 120f).toInt()
                        fft[i] = barEnergy.coerceIn(0, 127).toByte()
                    }

                    // Only overwrite if hardware visualizer didn't emit real data
                    if (visualizer == null || !visualizer!!.enabled) {
                        _waveformData.value = wave
                        _fftData.value = fft
                    }
                }
                delay(30)
            }
        }
    }

    fun setEqualizerEnabled(enabled: Boolean) {
        equalizer?.enabled = enabled
        bassBoost?.enabled = enabled
        virtualizer?.enabled = enabled
        _equalizerState.value = _equalizerState.value.copy(isEnabled = enabled)
    }

    fun setBandLevel(bandIndex: Int, levelMilliBels: Int) {
        try {
            equalizer?.setBandLevel(bandIndex.toShort(), levelMilliBels.toShort())
            val updatedBands = _equalizerState.value.bands.map {
                if (it.index == bandIndex) it.copy(currentLevelMilliBels = levelMilliBels) else it
            }
            _equalizerState.value = _equalizerState.value.copy(
                bands = updatedBands,
                currentPreset = "Custom"
            )
        } catch (e: Exception) {
            Log.e("AudioPlayerEngine", "Failed to set band level: ${e.message}")
        }
    }

    fun setBassBoost(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        try {
            bassBoost?.setStrength(clamped.toShort())
        } catch (_: Exception) {}
        _equalizerState.value = _equalizerState.value.copy(bassBoost = clamped)
    }

    fun setVirtualizer(strength: Int) {
        val clamped = strength.coerceIn(0, 1000)
        try {
            virtualizer?.setStrength(clamped.toShort())
        } catch (_: Exception) {}
        _equalizerState.value = _equalizerState.value.copy(virtualizer = clamped)
    }

    fun applyPreset(presetName: String) {
        val bands = _equalizerState.value.bands.toMutableList()
        if (bands.isEmpty()) return

        val multipliers = when (presetName) {
            "Bass Boost" -> listOf(600, 400, 100, 0, -200)
            "Rock" -> listOf(500, 300, -100, 200, 500)
            "Pop" -> listOf(-100, 200, 500, 300, -100)
            "Jazz" -> listOf(300, 100, 200, 300, 200)
            "Metal" -> listOf(400, 100, -200, 200, 400)
            "Classical" -> listOf(400, 200, -100, 200, 300)
            "Dance" -> listOf(600, 400, 100, 300, 400)
            "Hip Hop" -> listOf(500, 400, 0, 200, 300)
            else -> listOf(0, 0, 0, 0, 0)
        }

        for (i in bands.indices) {
            val level = multipliers.getOrElse(i) { 0 }
            setBandLevel(i, level)
        }
        _equalizerState.value = _equalizerState.value.copy(currentPreset = presetName)
    }

    private fun startProgressTracker() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive && _isPlaying.value) {
                mediaPlayer?.let {
                    if (it.isPlaying) {
                        _currentPositionMs.value = it.currentPosition.toLong()
                    }
                }
                delay(200)
            }
        }
    }

    private fun releaseEffects() {
        try { visualizer?.release() } catch (_: Exception) {}
        visualizer = null
        try { equalizer?.release() } catch (_: Exception) {}
        equalizer = null
        try { bassBoost?.release() } catch (_: Exception) {}
        bassBoost = null
        try { virtualizer?.release() } catch (_: Exception) {}
        virtualizer = null
    }

    fun release() {
        progressJob?.cancel()
        fallbackBeatJob?.cancel()
        releaseEffects()
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        if (wakeLock?.isHeld == true) {
            try { wakeLock?.release() } catch (_: Exception) {}
        }
    }
}
