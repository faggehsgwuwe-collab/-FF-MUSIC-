package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.Song
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("SK MUSIC PRO", appName)
  }

  @Test
  fun `verify song duration formatting`() {
    val song = Song(
      id = 1L,
      title = "Test Song",
      artist = "SK MUZAMMEL",
      album = "Gold Hits",
      durationMs = 214_000L,
      uri = android.net.Uri.EMPTY
    )
    assertEquals("3:34", song.durationFormatted)
    assertNotNull(song.durationFormatted)
  }
}
